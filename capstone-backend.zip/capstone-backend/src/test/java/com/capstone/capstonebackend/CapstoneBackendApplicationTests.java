package com.capstone.capstonebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstoneBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
